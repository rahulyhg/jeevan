--
-- Database: `sram_cms`
--

-- --------------------------------------------------------

--
-- Table structure for table `sramcms_blocks`
--

CREATE TABLE `sramcms_blocks` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `is_mobile` tinyint(1) NOT NULL,
  `page` varchar(255) NOT NULL,
  `position` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `display` tinyint(2) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_delete` tinyint(1) NOT NULL DEFAULT '0',
  `order` int(11) NOT NULL,
  `sort` tinyint(2) NOT NULL,
  `params` text NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sramcms_blocks`
--

INSERT INTO `sramcms_blocks` (`id`, `title`, `slug`, `is_mobile`, `page`, `position`, `type`, `display`, `is_active`, `is_delete`, `order`, `sort`, `params`, `created`, `modified`) VALUES
(3, 'Test videgetetasdasd', '', 0, 'frontend/frontend/index', 'content_left', 'textwidgets', 1, 1, 0, 1, 0, '{"text_content":"<p>adasdasd<\\/p> <p>as<\\/p> <p>dasd<\\/p> <p>a<\\/p> <p>sdasd<\\/p> ","css_id":""}', '2017-03-24 14:57:14', '2017-03-25 06:36:58');

-- --------------------------------------------------------

--
-- Table structure for table `sramcms_cms_pages`
--

CREATE TABLE `sramcms_cms_pages` (
  `id` int(11) NOT NULL,
  `page_title` varchar(255) NOT NULL,
  `page_slug` varchar(255) NOT NULL,
  `page_description` longtext NOT NULL,
  `page_image` varchar(255) NOT NULL,
  `page_meta_title` varchar(255) NOT NULL,
  `page_meta_keyword` varchar(255) NOT NULL,
  `page_meta_description` varchar(255) NOT NULL,
  `page_template` varchar(55) NOT NULL DEFAULT 'full-width',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_delete` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `created_ip` varchar(255) NOT NULL,
  `modified` datetime NOT NULL,
  `modified_ip` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sramcms_cms_pages`
--

INSERT INTO `sramcms_cms_pages` (`id`, `page_title`, `page_slug`, `page_description`, `page_image`, `page_meta_title`, `page_meta_keyword`, `page_meta_description`, `page_template`, `is_active`, `is_delete`, `created`, `created_ip`, `modified`, `modified_ip`) VALUES
(1, 'About Us', 'about-us', '<p>SRAM &amp; MRAM LTD, a leading diversified business conglomerate headquartered in the United Kingdom, and KALAM MEDIA, an Indian media house, created the joint venture SRAM KALAM MEDIA LIMITED, headquartered in the United Kingdom.</p>\r\n\r\n<p>The objective of the JV will be to source high demand pan-Indian media and entertainment content and distribute it through a global network across the Americas, Europe, Far East and Australia. The initial objective is limited to meeting the huge vacuum existing in generating quality content at the grassroots exclusively for the Indian Diaspora spread across the global community. The concept is to create a global village that has access to all the information out of the Indian Sub-continent on its fingertips.</p>\r\n\r\n<p>The aim will be to synergise the strengths of Kalam Media as an integrator of information at the base level and use the global reach of SRAM which could change the way news is perceived and viewed. The whole market dynamics will be reworked based on the way the news will be gathered and distributed.</p>\r\n\r\n<p>The spirit is to achieve the &ldquo;For an Indian, of an Indian and by an Indian&rdquo;.</p>\r\n', '', 'About Us', 'About Us', 'About Us', 'full-width', 1, 0, '2016-12-08 18:09:52', '', '0000-00-00 00:00:00', ''),
(2, 'Editorial Policy', 'editorial-policy', '<p>What is Lorem Ipsum?</p>\r\n\r\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\r\n\r\n<p>Why do we use it?</p>\r\n\r\n<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using &#39;Content here, content here&#39;, making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for &#39;lorem ipsum&#39; will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>\r\n', '', 'Editorial Policy', 'Editorial Policy', 'Editorial Policy', 'full-width', 1, 1, '2016-12-08 18:10:13', '', '2017-03-24 08:05:31', ''),
(3, 'Corrections and Clarifications', 'corrections-and-clarifications', '<p>What is Lorem Ipsum?</p>\r\n\r\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\r\n\r\n<p>Why do we use it?</p>\r\n\r\n<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using &#39;Content here, content here&#39;, making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for &#39;lorem ipsum&#39; will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>\r\n', '', 'Corrections and Clarifications', 'Corrections and Clarifications', 'Corrections and Clarifications', 'full-width', 1, 0, '2016-12-08 18:10:36', '', '0000-00-00 00:00:00', ''),
(4, 'Advertise', 'advertise', '<p>What is Lorem Ipsum?</p>\r\n\r\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\r\n\r\n<p>Why do we use it?</p>\r\n\r\n<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using &#39;Content here, content here&#39;, making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for &#39;lorem ipsum&#39; will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>\r\n', '', 'Advertise', 'Advertise', 'Advertise', 'full-width', 0, 0, '2016-12-08 18:10:57', '', '2017-03-24 07:43:52', ''),
(5, 'Jobs', 'jobs', '<p>What is Lorem Ipsum?</p>\r\n\r\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\r\n\r\n<p>Why do we use it?</p>\r\n\r\n<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using &#39;Content here, content here&#39;, making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for &#39;lorem ipsum&#39; will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>\r\n', '', 'Jobs', 'Jobs', 'Jobs', 'full-width', 1, 0, '2016-12-08 18:11:13', '', '0000-00-00 00:00:00', ''),
(6, 'Terms of Use and Disclaimer', 'terms-of-use-and-disclaimer', '<div>\r\n<p>By accessing Electtv.com, a subsidiary of Sramkalam.Tv or any of its associate/group sites, you have read, understood and agree to be legally bound by the terms of the following disclaimer and user agreement:</p>\r\n\r\n<p>This Site is owned and operated by SramKalam Media Limited (&quot;the Company/SramKalam&quot;) and contains material which is derived in whole or in part from material supplied by the Company, various new agencies and other sources, and is protected by international copyright and trademark laws. The restrictions on use of the material and content on this SramKalam Site by the Subscriber are specified below. Except where specifically authorised, the Subscriber may not modify, copy, reproduce, republish, upload, post, transmit or distribute in any way any material from this site including code and software.</p>\r\n\r\n<p>The Company shall have the right at any time to change or modify the terms and conditions applicable to Subscriber&#39;s use of the SramKalam Site, or any part thereof, or to impose new conditions, including but not limited to, adding fees and charges for use. Such changes, modifications, additions or deletions shall be effective immediately upon notice thereof, which may be given by means including but not limited to, posting on the SramKalam Site, or by electronic or conventional mail, or by any other means by which Subscriber obtains notice thereof. Any use of the SramKalam Site by Subscriber after such notice shall be deemed to constitute acceptance by Subscriber of such changes, modifications or additions.</p>\r\n\r\n<p><strong>Terms of Use:</strong></p>\r\n\r\n<p>By visiting our site you are agreeing to be bound by the following terms and conditions. We may change these terms and conditions at any time. Your continued use of Sramkalam.tv means that you accept any new or modified terms and conditions that we come up with. Please re-visit the `Terms of Use&#39; link at our site from time to time to stay abreast of any changes that we may introduce.</p>\r\n\r\n<p>The term ` Electtv.com, a subsidiary of Sramkalam.Tv &#39; is used through this entire Terms of Use document to refer to the website, its owners and the employees and associates of the owner</p>\r\n\r\n<p><strong>1) REGISTRATION</strong></p>\r\n\r\n<p>By registering, you certify that all information you provide, now or in the future, is accurate. Your registration at Electtv.com, a subsidiary of Sramkalam.tv is valid for 90 days from the date you first login and is automatically renewed for a period of 90 days every time you login thereafter. If you do not login at Electtv.com, a subsidiary Sramkalam.Tv for a continuous period of 90 days your registration could be automatically cancelled. Sramkalam.tv reserves the right, in its sole discretion, to deny you access to this website or any portion thereof without notice for the following reasons (a) immediately by Electtv.com, a subsidiary Sramkalam.Tv for any unauthorized access or use by you (b) immediately by Electtv.com, a subsidiary Sramkalam.Tvif you assign or transfer (or attempt the same) any rights granted to you under this Agreement; (c) immediately, if you violate any of the other terms and conditions of this User Agreement</p>\r\n\r\n<p><strong>2) LICENSE:</strong></p>\r\n\r\n<p>Electtv.com, a subsidiary Sramkalam.Tv hereby grants you a limited, non-exclusive, non-assignable and non-transferable license to access Electtv.com, a subsidiary Sramkalam.Tvprovided and expressly conditioned upon your agreement that all such access and use shall be governed by all of the terms and conditions set forth in this USER AGREEMENT.</p>\r\n\r\n<p><strong>3) COPYRIGHT &amp; NO RETRANSMISSION OF INFORMATION:</strong></p>\r\n\r\n<p>Electtv.com, a subsidiary Sramkalam.Tv as well as the design and information contained in this site is the valuable, exclusive property of Electtv.com, a subsidiary Sramkalam.Tv, and nothing in this Agreement shall be construed as transferring or assigning any such ownership rights to you or any other person or entity.</p>\r\n\r\n<p>You may not resell, redistribute, broadcast or transfer information, software and applications or use the information, software and applications provided by Electtv.com, a subsidiary Sramkalam.Tv in a searchable, machine-readable database unless separately and specifically authorized in writing by Electtv.com, a subsidiary Sramkalam.Tv prior to such use. You may not rent, lease, sublicense, distribute, transfer, copy, reproduce, publicly display, publish, adapt, store or time-share Electtv.com, a subsidiary Sramkalam.Tv, any part thereof, or any of the software, application or information received or accessed therefrom to or through any other person or entity unless separately and specifically authorized in writing by Electtv.com, a subsidiary Sramkalam.Tv prior to such use. In addition, you may not remove, alter or obscure any copyright, legal or proprietary notices in or on any portions of Electtv.com, a subsidiary Sramkalam.Tv without prior written authorization. Except as set forth herein, any other use of the information, software or application contained in this site requires the prior written consent of SRAM and may require a separate fee.</p>\r\n\r\n<p><strong>4) DELAYS IN SERVICES:</strong></p>\r\n\r\n<p>Neither Electtv.com, a subsidiary Sramkalam.Tv(including its and their directors, employees, affiliates, agents, representatives or subcontractors) shall be liable for any loss or liability resulting, directly or indirectly, from delays or interruptions due to electronic or mechanical equipment failures, telephone interconnect problems, defects, weather, strikes, walkouts, fire, acts of God, riots, armed conflicts, acts of war, or other like causes. Electtv.com, a subsidiary Sramkalam.Tv shall have no responsibility to provide you access to Electtv.com, a subsidiary Sramkalam.Tv while interruption of Electtv.com, a subsidiary Sramkalam.Tv is due to any such cause shall continue.</p>\r\n\r\n<p><strong>5) LIABILITY DISCLAIMER :</strong></p>\r\n\r\n<p>YOU EXPRESSLY AGREE THAT USE OF THE WEBSITE IS AT YOUR SOLE RISK.</p>\r\n\r\n<p>THE CONTENTS, INFORMATION, SOFTWARE, PRODUCTS, FEATURES AND SERVICES PUBLISHED ON THIS WEB SITE MAY INCLUDE INACCURACIES OR TYPOGRAPHICAL ERRORS. CHANGES ARE PERIODICALLY ADDED TO THE CONTENTS HEREIN. Electtv.com, a subsidiary Sramkalam.Tv AND/OR ITS RESPECTIVE SUPPLIERS MAY MAKE IMPROVEMENTS AND/OR CHANGES IN THIS WEB SITE AT ANY TIME. THIS WEB SITE MAY BE TEMPORARILY UNAVAILABLE FROM TIME TO TIME DUE TO REQUIRED MAINTENANCE, TELECOMMUNICATIONS INTERRUPTIONS, OR OTHER DISRUPTIONS. Electtv.com, a subsidiary Sramkalam.Tv (AND ITS OWNERS, SUPPLIERS, CONSULTANTS, ADVERTISERS, AFFILIATES, PARTNERS, EMPLOYEES OR ANY OTHER ASSOCIATED ENTITIES, ALL COLLECTIVELY REFERRED TO AS ASSOCIATED ENTITIES HEREAFTER) SHALL NOT BE LIABLE TO USER OR MEMBER OR ANY THIRD PARTY SHOULD Electtv.com, a subsidiary Sramkalam.Tv EXERCISE ITS RIGHT TO MODIFY OR DISCONTINUE ANY OR ALL OF THE CONTENTS, INFORMATION, SOFTWARE, PRODUCTS, FEATURES AND SERVICES PUBLISHED ON THIS WEBSITE.</p>\r\n\r\n<p>IN NO EVENT SHALL Electtv.com, a subsidiary Sramkalam.Tv AND/OR ITS ASSOCIATED ENTITIES BE LIABLE FOR ANY DIRECT, INDIRECT, PUNITIVE, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES ARISING OUT OF OR IN ANY WAY CONNECTED WITH THE USE OF THIS WEB SITE OR WITH THE DELAY OR INABILITY TO USE THIS WEBSITE, OR FOR ANY CONTENTS, INFORMATION, SOFTWARE, PRODUCTS, FEATURES AND SERVICES OBTAINED THROUGH THIS WEB SITE, OR OTHERWISE ARISING OUT OF THE USE OF THIS WEB SITE, WHETHER BASED ON CONTRACT, TORT, STRICT LIABILITY OR OTHERWISE, EVEN IF Electtv.com, a subsidiary Sramkalam.Tv OR ANY OF ITS ASSOCIATED ENTITIES HAS BEEN ADVISED OF THE POSSIBILITY OF DAMAGES.</p>\r\n\r\n<p><strong>6) USE OF MESSAGE BOARDS, CHAT ROOMS AND OTHER COMMUNICATION FORUMS:</strong></p>\r\n\r\n<p>If this Web site may contain message/bulletin boards, chat rooms, or other message or communication facilities (collectively, &quot;Forums&quot;), you agree to use the Forums only to send and receive messages and material that are proper and related to the particular Forum. By way of example, and not as a limitation, you agree that when using a Forum, you shall not do any of the following:</p>\r\n\r\n<ul>\r\n	<li>\r\n	<p>Defame, abuse, harass, stalk, threaten or otherwise violate the legal rights (such as rights of privacy and publicity) of others.</p>\r\n	</li>\r\n	<li>\r\n	<p>Publish, post, distribute or disseminate any defamatory, infringing, obscene, indecent or unlawful material or information</p>\r\n	</li>\r\n	<li>\r\n	<p>Upload files that contain software or other material protected by intellectual property laws (or by rights of privacy of publicity) unless you own or control the rights thereto or have received all necessary consents.</p>\r\n	</li>\r\n	<li>\r\n	<p>Upload files that contain viruses, corrupted files, or any other similar software or programs that may damage the operation of another&rsquo;s computer.</p>\r\n	</li>\r\n	<li>\r\n	<p>Conduct or forward surveys, contests, or chain letters.</p>\r\n	</li>\r\n	<li>\r\n	<p>Download any file posted by another user of a Forum that you know, or reasonably should know, cannot be legally distributed in such manner.</p>\r\n	</li>\r\n</ul>\r\n\r\n<p>All Forums are public and not private communications. Chats, postings, conferences, and other communications by other users are not endorsed by Electtv.com, a subsidiary Sramkalam.Tv, and such communications shall not be considered reviewed, screened, or approved by Electtv.com, a subsidiary Sramkalam.Tv. Electtv.com, a subsidiary Sramkalam.Tv reserves the right for any reason to remove without notice any contents of the Forums received from users, including without limitation message board postings.</p>\r\n\r\n<p><strong>7) EQUIPMENT AND OPERATION</strong></p>\r\n\r\n<p>You shall provide and maintain all telephone/internet and other equipment necessary to access Electtv.com, a subsidiary Sramkalam.Tv, and the costs of any such equipment and/or telephone/internet connections or use, including any applicable taxes, shall be borne solely by you. You are responsible for operating your own equipment used to access Electtv.com, a subsidiary Sramkalam.Tv</p>\r\n\r\n<p><strong>8) LINKS TO THIRD PARTY SITES</strong></p>\r\n\r\n<p>The links in this site will allow you to leave Electtv.com, a subsidiary Sramkalam.Tv The linked sites are not under the control of Electtv.com, a subsidiary Sramkalam.Tv .Electtv.com, a subsidiary Sramkalam.Tv has not reviewed, nor approved these sites and is not responsible for the contents or omissions of any linked site or any links contained in a linked site. The inclusion of any linked site does not imply endorsement by Electtv.com, a subsidiary Sramkalam.Tv of the site. Third party links to Electtv.com, a subsidiary Sramkalam.Tv shall be governed by a separate agreement.</p>\r\n\r\n<p><strong>9) INDEMNIFICATION:</strong></p>\r\n\r\n<p>YOU SHALL INDEMNIFY, DEFEND AND HOLD HARMLESS Electtv.com, a subsidiary Sramkalam.Tv (INCLUDING ITS AND THEIR OFFICERS, DIRECTORS, EMPLOYEES, AFFILIATES, GROUP COMPANIES, AGENTS, REPRESENTATIVES OR SUBCONTRACTORS) FROM ANY AND ALL CLAIMS AND LOSSES IMPOSED ON, INCURRED BY OR ASSERTED AS A RESULT OF OR RELATED TO: (a) your access and use of Electtv.com, a subsidiary Sramkalam.Tv (b) any non-compliance by user with the terms and conditions hereof; or (c) any third party actions related to users receipt and use of the information, whether authorized or unauthorized. Any clause declared invalid shall be deemed severable and not affect the validity or enforceability of the remainder. These terms may only be amended in a writing signed by Electtv.com, a subsidiary Sramkalam.Tv.</p>\r\n\r\n<p><strong>10) CONFLICTING TERMS:</strong></p>\r\n\r\n<p>If there is any conflict between this User Agreement and other documents, this User Agreement shall govern, whether such order or other documents is prior to or subsequent to this User Agreement, or is signed or acknowledged by any director, officer, employee, representative or agent of Electtv.com, a subsidiary Sramkalam.Tv.</p>\r\n\r\n<p><strong>11) CONFIDENTIALITY/NON-COMPETITION CLAUSE:</strong></p>\r\n\r\n<p>You agree to keep the information received from the Electtv.com, a subsidiary Sramkalam.Tv and services CONFIDENTIAL and will NOT Disclose the knowledge gained to other any person or firm for any reason. You hereby consent to the Jurisdiction of the Crown Courts of United Kingdom with respect to violation of any part of this Agreement.</p>\r\n\r\n<p><strong>12) TERMINATION:</strong></p>\r\n\r\n<p>This User Agreement and the license rights granted hereunder shall remain in full force and effect unless terminated or canceled for any of the following reasons: (a) immediately by Electtv.com, a subsidiary Sramkalam.Tv for any unauthorized access or use by you (b) immediately by Electtv.com, a subsidiary Sramkalam.Tv if you assign or transfer (or attempt the same) any rights granted to you under this Agreement; (c) immediately, if you violate any of the other terms and conditions of this User Agreement. Termination or cancellation of this Agreement shall not effect any right or relief to which Electtv.com, a subsidiary Sramkalam.Tv may be entitled, at law or in equity. Upon termination of this User Agreement, all rights granted to you will terminate and revert to Electtv.com, a subsidiary Sramkalam.Tv. Except as set forth herein, regardless of the reason for cancellation or termination of this User Agreement, the fee charged if any for access to Electtv.com, a subsidiary Sramkalam.Tv is non-refundable for any reason.</p>\r\n\r\n<p><strong>13) JURISDICTION:</strong></p>\r\n\r\n<p>The terms of this agreement are exclusively based on and subject to the law of the United Kingdom. You hereby consent to the exclusive jurisdiction and venue of courts in London, United Kimgdom in all disputes arising out of or relating to the use of this website. Use of this website is unauthorized in any jurisdiction that does not give effect to all provisions of these terms and conditions, including without limitation this&nbsp;paragraph.</p>\r\n</div>\r\n', '', 'Terms of Service', 'Terms of Service', 'Terms of Service', 'full-width', 1, 0, '2016-12-08 18:11:31', '', '0000-00-00 00:00:00', ''),
(7, 'Privacy Policy', 'privacy-policy', '<p><strong>SRAM KALAM</strong> recognizes the importance of protecting the privacy of information and will keep the information you entrust to us safely and securely</p>\r\n\r\n<p><strong>What this Privacy Policy Covers.</strong></p>\r\n\r\n<p>This policy tells you how SRAM KALAM collects information from you, how we protect it and how we use it, and share all personal information which you provide when you use any of SRAM KALAM sites (the &quot;Sites&quot;), unless otherwise specified on the relevant site where a different privacy policy will be displayed This policy does not apply to the practices of companies that SRAM KALAM does not own or control or to people that SRAM KALAM does not employ or manage.</p>\r\n\r\n<p><strong>Information Collection and Use</strong></p>\r\n\r\n<p>We respect each visitor&#39;s right to personal privacy. To that end, we collect and use information throughout our web site only as disclosed in this Privacy Policy. This statement applies solely to the information collected on Electtv.com, a subsidiary of Sramkalam.tv.</p>\r\n\r\n<p>We will collect personally identifiable information from you in a variety of ways including directly from you when you register on the Sites, use other SRAM KALAM services, enter competitions or prize draws, navigate around our Sites or respond to communications from us. SRAM KALAM may also receive personally identifiable information from, third parties including our related companies, our business partners and publicly available sources of information.</p>\r\n\r\n<p>The following is what we normally collect about you to help us provide you with our services, where we can:</p>\r\n\r\n<ul>\r\n	<li>Information on how you use our website, including details of your domain name and Internet Protocol address, operating system, browser, cookies, time spent on a page or content, and the route you took to navigate through the pages.</li>\r\n	<li>Other data, from time to time, to help us provide you with improved products and services.</li>\r\n</ul>\r\n\r\n<p>If you choose not to provide us with certain information we may not be able to provide you with a particular service.</p>\r\n\r\n<p>SRAM KALAM also automatically receives and records information on our server logs from your browser including your IP address, SRAM KALAM! cookie information and the page you requested.</p>\r\n\r\n<p>In addition, when you use SRAM KALAM&#39;s services, you may make some of your personal information public. If you post personal information online that is accessible to the public, you may receive unsolicited messages from other parties in return and SRAM KALAM will not be responsible for the use or misuse of such information. The main uses of your personal information are to verify your identity; to help provide our services; to administer those services; to enable us to review and improve our service to provide access to certain areas of the website; to personalise your visit to our site; to run competitions and games and to assist with advertising and other revenue generation functions. The information we collect is also used to notify visitors about events, changes and other information about this web site. The information we collect is never shared with other organizations for commercial or other purposes.</p>\r\n\r\n<p>This information may be used for marketing (where you have agreed to this) and for market research purposes, including internal demographic studies, to provide, optimise and personalise our services and to send you newsletters and information (where you have agreed to this) about our products and services.</p>\r\n\r\n<p>We may use information about you to create a picture of your interests. This will allow us to understand our customers and visitors better, so we can make our services and marketing more relevant. Information that we use in this way may include:</p>\r\n\r\n<ol>\r\n	<li>information about your use of this and other SRAM KALAM Sites;</li>\r\n	<li>household classification data,</li>\r\n	<li>your responses to communications from us;</li>\r\n	<li>your interaction with other parts of the SRAM KALAM Group;</li>\r\n	<li>information you provide when you register on a Site;</li>\r\n	<li>customer surveys;</li>\r\n	<li>information provided by other companies, where you gave them permission to share this information. We may use a variety of technical methods such as cookies and web beacons to collate this information (see the section below on &quot;Use of Cookies&quot; for further information).</li>\r\n</ol>\r\n\r\n<p><strong>Information Sharing and Disclosure</strong></p>\r\n\r\n<p>SRAM KALAM will NOT disclose personally identifiable information about you to third parties except in the following situations:</p>\r\n\r\n<ul>\r\n	<li>We have your consent to share the information;</li>\r\n	<li>We need to share your information to provide the product or service you have requested;</li>\r\n	<li>We need to share the information with certain service partners in order to respond to your comments or to resolve service issues. (Unless we tell you differently, these partners have no independent right to use this information except to respond to your comments or to resolve the service issues.);&nbsp;</li>\r\n	<li>We respond to requests from any Indian or foreign government, security, defence, revenue, regulatory or other authority, agency or officer;&nbsp;</li>\r\n	<li>We respond to subpoenas, court orders or legal proceedings;&nbsp;</li>\r\n	<li>When required by law that such action is necessary to protect and defend the rights of property Electtv.com, a subsidiary of Sramkalam.tv.</li>\r\n	<li>When applicable law or regulation requires disclosure of information to protect the safety or security of users of our Sites;</li>\r\n	<li>We find that your actions on our web sites violate the SRAM KALAM Terms of Service or any of our usage guidelines for specific products or services;</li>\r\n	<li>If we sell the business of some of the SRAM KALAM group of companies to another organisation or merge with other businesses. In this case, the buyer will only be able to use your information as set out in this Privacy Policy;&nbsp;</li>\r\n	<li>If we use third party processors to administer and process your personal information for the purposes notified in the Privacy Policy, e.g. for hosting activities related to the use of our Sites or services; or</li>\r\n	<li>&nbsp;We may need to share details with third parties (such as auditors or legal advisors) to obtain advice. Any such processing will be governed by an agreement in the form required by law, preserving any statutory data protection rights.</li>\r\n	<li>We may share your information with other members of the SRAM KALAM Group. As used in this Privacy Policy the SRAM KALAM Group includes SRAM KALAM MEDIA LIMITED, United Kingdom and all of its subsidiary and affiliated entities, including companies such as those branded under SRAM labels . In this Privacy Policy &quot;we&quot;, &quot;us&quot;, &quot;our&quot; and &quot;ourselves&quot; means any member of this Group.</li>\r\n</ul>\r\n\r\n<p>People we may disclose your personal information will include:</p>\r\n\r\n<p>Who has access to the information at SRAM KALAM?</p>\r\n\r\n<ul>\r\n	<li>Members of SRAM KALAM ;</li>\r\n	<li>our related companies;</li>\r\n	<li>\r\n	<p>advertisers and content partners, either in an aggregate form eg. &ldquo;5,000 users clicked on a banner ad&rdquo;;</p>\r\n	</li>\r\n	<li>\r\n	<p>Credit-reporting and fraud-checking agencies;</p>\r\n	</li>\r\n	<li>\r\n	<p>our professional advisers, including our accountants, auditors and lawyers;</p>\r\n	</li>\r\n	<li>\r\n	<p>other telecommunication and information service providers;</p>\r\n	</li>\r\n	<li>\r\n	<p>by disclosing individual records such as IP addresses as may be required by law; or</p>\r\n	</li>\r\n	<li>\r\n	<p>government and regulatory authorities and other organisations, as required or authorised by law. We will ensure that these people only use such information to perform the above functions, and that they have adequate procedures in place to deal with your data securely. Some of these people may be based outside India.</p>\r\n	</li>\r\n</ul>\r\n\r\n<p><strong>Use of information for marketing</strong></p>\r\n\r\n<p>In line with any permission you give us, we may send you direct marketing about our own, or carefully selected third parties&#39; goods and services and disclose your information to other organisations that may send direct marketing to you. You can change your marketing preferences if you are registered with us. In addition, you can unsubscribe from email communications via unsubscribe links provided in communications sent to you.</p>\r\n\r\n<p><strong>Link from or to Other Sites</strong></p>\r\n\r\n<p>As a means of providing useful resources to our users,&nbsp;<a href="http://electtv.com/">Electtv.com</a>, a subsidiary of Sramkalam.Tv &nbsp;provides links to other web sites. We try to carefully choose web sites that we believe are useful and meet our high standards. However, because web sites can change so quickly, we do not guarantee the standards of any website links we provide nor do we imply endorsement.&nbsp;<a href="http://electtv.com/">Electtv.com</a>, a subsidiary of Sramkalam.tv &nbsp;is not responsible for the data and privacy policies, content or security of other websites that are linked to our site. . You should be aware that when you are on our Sites you could be directed to other sites where the personal information collected is outside of our control. The privacy policy of the new site will govern the information obtained from you on that site.</p>\r\n\r\n<p><strong>Access to your account information</strong></p>\r\n\r\n<p>You can access and change the information that you provided during registration. Simply click on this&nbsp;<a href="http://www.electtv.com/">Electtv.com</a>, a subsidiary of Sramkalam.Tv&nbsp;and then log in with your member name and password wherever necessary. There are instructions on the start page to help you recover your password if you&#39;ve forgotten it. You can also contact us via e-mail by clicking &quot;Contact Us&quot; bar of&nbsp;<a href="http://www.electtv.tv/">Electtv.com</a>, a subsidiary of Sramkalam.Tv &nbsp;page, or send an email directly to&nbsp;<a href="mailto:editor@sramkalam.tv">editor@sramkalam.tv.</a>&nbsp;Please include information in the e-mail that will help us identify your account so we can assist you with your inquiry or request.</p>\r\n\r\n<p><strong>Cookies</strong></p>\r\n\r\n<p>We collect information through technology to make our Sites and other content or services which we make available to you more interesting and useful to you. For instance, when you come to one of our Sites via your computer or other media device, we may combine your visitor session information or other information collected through cookies, web beacons and other technical methods with personally identifiable information in order to understand and improve your online experiences and to determine what products, promotions and services you prefer or are likely to be of interest to you. Cookies are pieces of information that a Site sends to your computer or other media device while you are viewing or interacting with the Site. We use cookies for a variety of purposes including tracking usage on our Sites in order to- enhance our guests&#39; experience on our Sites and to learn more about your preferences and interests Web beacons are small pieces of data that are embedded in images on the pages of Sites. We also use these technical methods to analyse the traffic patterns on our Sites, such as the frequency with which our users visit various parts of our Sites.</p>\r\n\r\n<p>SRAM KALAM ensures that all information collected and accessed by SRAM KALAM through the access of these cookies will be maintained in accordance with this Privacy Policy. SRAM KALAM allows other companies that are presenting advertisements on some of our pages to set and access their cookies on your computer. Other companies&#39; use of their cookies is subject to their own privacy policies. Advertisers or other companies do not have access to SRAM KALAM&#39;s cookies.</p>\r\n\r\n<p><strong>Security</strong></p>\r\n\r\n<p>We take various precautions to keep your personal information secure from unauthorized access and will store your personal information for so long as it is necessary to provide you our services or for archive purposes. You are responsible for keeping your User ID and password secure and you should not disclose them to anyone.</p>\r\n\r\n<p><strong>Notification of Changes</strong></p>\r\n\r\n<p>SRAM KALAM may amend this Privacy Policy from time to time and we will post the latest version on this and all our other Sites. If we ever wish to use your personal information in a way which is incompatible with the information in this Privacy Policy, we will only do so with your consent.</p>\r\n\r\n<p><strong>Acceptance of Privacy Policy</strong></p>\r\n\r\n<p>Your right to access this website is conditional upon your full acceptance of this Privacy Policy and by accessing the Sites you signify your consent that we store and process your personal data in accordance with this Privacy Policy.</p>\r\n\r\n<p><strong>Contact Us</strong></p>\r\n\r\n<p>If you need further assistance or have queries about our use of personal information, please send us an email with your questions or comments to&nbsp;<a href="mailto:editor@sramkalam.tv">editor@sramkalam.tv</a></p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n', '', 'Privacy Policy', 'Privacy Policy', 'Privacy Policy', 'full-width', 1, 0, '2016-12-08 18:11:58', '', '0000-00-00 00:00:00', ''),
(8, 'Ad Choices', 'ad-choices', '<p>What is Lorem Ipsum?</p>\r\n\r\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\r\n\r\n<p>Why do we use it?</p>\r\n\r\n<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using &#39;Content here, content here&#39;, making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for &#39;lorem ipsum&#39; will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>\r\n', '', 'Ad Choices', 'Ad Choices', 'Ad Choices', 'full-width', 0, 0, '2016-12-08 18:12:15', '', '2017-03-24 08:05:13', ''),
(9, 'Contact Us', 'contact-us', '<p>What is Lorem Ipsum?</p>\r\n\r\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\r\n\r\n<p>Why do we use it?</p>\r\n\r\n<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using &#39;Content here, content here&#39;, making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for &#39;lorem ipsum&#39; will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>\r\n', '', 'Contact Us', 'Contact Us', 'Contact Us', 'full-width', 0, 1, '2016-12-08 18:12:35', '', '2017-03-24 08:05:25', ''),
(10, 'Sales Enquiries', 'sales-enquiries', '<p>What is Lorem Ipsum?</p>\r\n\r\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\r\n\r\n<p>Why do we use it?</p>\r\n\r\n<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using &#39;Content here, content here&#39;, making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for &#39;lorem ipsum&#39; will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>\r\n', '', 'Sales Enquiries', 'Sales Enquiries', 'Sales Enquiries', 'full-width', 0, 0, '2016-12-08 18:12:54', '', '2017-03-24 08:05:09', ''),
(11, 'Advertise With Us', 'advertise-with-us', '<p>What is Lorem Ipsum?</p>\r\n\r\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\r\n\r\n<p>Why do we use it?</p>\r\n\r\n<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using &#39;Content here, content here&#39;, making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for &#39;lorem ipsum&#39; will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>\r\n', '', 'Advertise With Us', 'Advertise With Us', 'Advertise With Us', 'full-width', 1, 1, '2016-12-08 18:13:12', '', '2017-03-24 08:05:22', '');

-- --------------------------------------------------------

--
-- Table structure for table `sramcms_log`
--

CREATE TABLE `sramcms_log` (
  `id` bigint(20) NOT NULL,
  `created` datetime NOT NULL,
  `msg` text NOT NULL,
  `type` varchar(255) NOT NULL,
  `action_type_id` int(11) NOT NULL COMMENT '1=>Add,2=>Edit,3=>Delete,4=>Status change',
  `login_id` bigint(20) NOT NULL,
  `ip_address` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sramcms_log`
--

INSERT INTO `sramcms_log` (`id`, `created`, `msg`, `type`, `action_type_id`, `login_id`, `ip_address`) VALUES
(1, '2017-03-24 11:16:22', 'A Menu Groups  has been edited by admin :', 'Menu Groups', 2, 1, '::1'),
(2, '2017-03-24 11:17:13', 'A Menu Groups  has been edited by admin :', 'Menu Groups', 2, 1, '::1'),
(3, '2017-03-24 11:17:43', 'A Menu Groups  has been edited by admin :tksubhashraj14@gmail.com', 'Menu Groups', 2, 1, '::1'),
(4, '2017-03-24 11:17:49', 'A Menu Groups  has been edited by admin :tksubhashraj14@gmail.com', 'Menu Groups', 2, 1, '::1'),
(5, '2017-03-24 11:17:56', 'A Menu Groups  has been edited by admin :tksubhashraj14@gmail.com', 'Menu Groups', 2, 1, '::1'),
(6, '2017-03-24 11:18:03', 'A Menus About us has been edited by admin :tksubhashraj14@gmail.com', 'Menus', 2, 1, '::1'),
(7, '2017-03-24 11:18:11', 'A Menus About us has been edited by admin :tksubhashraj14@gmail.com', 'Menus', 2, 1, '::1'),
(8, '2017-03-24 11:18:26', 'A Menus  has been edited by admin :tksubhashraj14@gmail.com', 'Menus', 2, 1, '::1'),
(9, '2017-03-24 11:18:35', 'A Menus About us has been edited by admin :tksubhashraj14@gmail.com', 'Menus', 2, 1, '::1'),
(10, '2017-03-24 11:18:43', 'A Menus  has been edited by admin :tksubhashraj14@gmail.com', 'Menus', 2, 1, '::1'),
(11, '2017-03-24 11:20:22', 'A Menus About us has been Deactivated  by admin :tksubhashraj14@gmail.com', 'Menus', 4, 1, '::1'),
(12, '2017-03-24 11:20:34', 'A Menus About us has been deleted  by admin :tksubhashraj14@gmail.com', 'Menus', 3, 1, '::1'),
(13, '2017-03-24 11:26:28', 'A New Menu Groups Fooadasd asdasdasd has been added by admin :tksubhashraj14@gmail.com', 'Menu Groups', 1, 1, '::1'),
(14, '2017-03-24 11:26:32', 'A Menu Groups  has been deleted  by admin :tksubhashraj14@gmail.com', 'Menu Groups', 3, 1, '::1'),
(15, '2017-03-24 11:26:53', 'A Menu Groups  has been deleted  by admin :tksubhashraj14@gmail.com', 'Menu Groups', 3, 1, '::1'),
(16, '2017-03-24 11:27:31', 'A Menu Groups Header Menu has been deleted  by admin :tksubhashraj14@gmail.com', 'Menu Groups', 3, 1, '::1'),
(17, '2017-03-24 11:29:15', 'A Menus About us has been Activated  by admin :tksubhashraj14@gmail.com', 'Menus', 4, 1, '::1'),
(18, '2017-03-24 11:40:30', 'A Menus About us has been Deactivated  by admin :tksubhashraj14@gmail.com', 'Menus', 4, 1, '::1'),
(19, '2017-03-24 11:41:08', 'A Menus Corrections and Clarifications has been Deactivated  by admin :tksubhashraj14@gmail.com', 'Menus', 4, 1, '::1'),
(20, '2017-03-24 11:41:25', 'A Menus Corrections and Clarifications has been Activated  by admin :tksubhashraj14@gmail.com', 'Menus', 4, 1, '::1'),
(21, '2017-03-24 11:41:55', 'A Menus Corrections and Clarifications has been Deactivated  by admin :tksubhashraj14@gmail.com', 'Menus', 4, 1, '::1'),
(22, '2017-03-24 11:45:16', 'A Menus About us has been deleted  by admin :tksubhashraj14@gmail.com', 'Menus', 3, 1, '::1');

-- --------------------------------------------------------

--
-- Table structure for table `sramcms_master_admin`
--

CREATE TABLE `sramcms_master_admin` (
  `admin_id` int(11) NOT NULL,
  `admin_username` varchar(100) DEFAULT NULL,
  `admin_email_address` varchar(100) DEFAULT NULL,
  `admin_password` varchar(155) DEFAULT NULL,
  `admin_status` enum('A','I') NOT NULL DEFAULT 'I',
  `admin_pass_key` varchar(50) DEFAULT NULL,
  `admin_updated_on` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sramcms_master_admin`
--

INSERT INTO `sramcms_master_admin` (`admin_id`, `admin_username`, `admin_email_address`, `admin_password`, `admin_status`, `admin_pass_key`, `admin_updated_on`) VALUES
(1, 'admin', 'tksubhashraj14@gmail.com', '$2a$08$RLbVYes/SDUgUxbwxAbgX.FAyPqFX5ZgkEtJmRD4UkgSkYm0S4kS.', 'A', NULL, '2016-02-02 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `sramcms_master_admin_login_history`
--

CREATE TABLE `sramcms_master_admin_login_history` (
  `login_id` bigint(20) NOT NULL,
  `login_time` datetime DEFAULT NULL,
  `login_ip` varchar(20) DEFAULT NULL,
  `login_admin_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sramcms_master_admin_login_history`
--

INSERT INTO `sramcms_master_admin_login_history` (`login_id`, `login_time`, `login_ip`, `login_admin_id`) VALUES
(12, '2016-02-19 13:10:46', '::1', 1),
(13, '2016-02-19 13:48:45', '::1', 1),
(14, '2016-02-19 15:36:28', '::1', 1),
(15, '2016-02-20 06:55:26', '::1', 1),
(16, '2016-02-20 10:45:49', '::1', 1),
(17, '2016-02-20 10:48:13', '::1', 1),
(18, '2016-02-22 06:16:15', '::1', 1),
(19, '2016-02-22 07:59:41', '::1', 1),
(20, '2016-02-22 10:05:35', '192.168.2.65', 1),
(21, '2016-02-22 14:44:36', '127.0.0.1', 1),
(22, '2016-02-22 14:57:39', '127.0.0.1', 1),
(23, '2016-02-22 10:52:19', '::1', 1),
(24, '2016-02-22 10:52:55', '::1', 1),
(25, '2016-02-22 10:53:28', '::1', 1),
(26, '2016-02-22 10:55:29', '::1', 1),
(27, '2016-02-22 10:55:49', '::1', 1),
(28, '2016-02-22 15:41:23', '127.0.0.1', 1),
(29, '2016-02-23 05:42:04', '192.168.2.69', 1),
(30, '2016-02-23 06:35:16', '192.168.2.69', 1),
(31, '2016-02-23 06:38:49', '192.168.2.69', 1),
(32, '2016-02-24 05:58:47', '::1', 1),
(33, '2016-02-24 06:05:36', '::1', 1),
(34, '2016-02-24 06:06:08', '::1', 1),
(35, '2016-02-24 06:07:19', '::1', 1),
(36, '2016-02-24 10:17:29', '::1', 1),
(37, '2016-02-24 10:45:13', '192.168.2.113', 1),
(38, '2016-02-24 11:04:21', '::1', 1),
(39, '2016-02-24 11:21:19', '::1', 1),
(40, '2016-02-24 11:54:32', '192.168.2.113', 1),
(41, '2016-02-24 11:56:30', '192.168.2.113', 1),
(42, '2016-02-24 12:02:27', '192.168.2.113', 1),
(43, '2016-02-24 12:50:55', '::1', 1),
(44, '2016-02-24 13:00:39', '192.168.2.113', 1),
(45, '2016-02-24 13:02:58', '192.168.2.113', 1),
(46, '2016-02-24 13:03:23', '192.168.2.113', 1),
(47, '2016-02-24 13:09:58', '192.168.2.113', 1),
(48, '2016-02-24 13:11:38', '192.168.2.113', 1),
(49, '2016-02-24 14:01:35', '192.168.2.113', 1),
(50, '2016-02-24 15:04:45', '192.168.2.113', 1),
(51, '2016-02-24 15:08:49', '192.168.2.113', 1),
(52, '2016-02-24 15:30:37', '192.168.2.113', 1),
(53, '2016-02-25 06:17:48', '::1', 1),
(54, '2016-02-25 06:21:35', '192.168.2.113', 1),
(55, '2016-02-25 07:28:55', '192.168.2.65', 1),
(56, '2016-02-25 08:17:53', '192.168.2.65', 1),
(57, '2016-02-25 08:39:54', '192.168.2.113', 1),
(58, '2016-02-25 09:43:07', '192.168.2.65', 1),
(59, '2016-02-25 10:52:51', '192.168.2.113', 1),
(60, '2016-02-25 13:21:58', '192.168.2.113', 1),
(61, '2016-02-25 15:21:06', '::1', 1),
(62, '2016-02-26 06:06:42', '::1', 1),
(63, '2016-02-26 06:20:21', '::1', 1),
(64, '2016-02-26 13:02:30', '127.0.0.1', 1),
(65, '2016-02-26 09:08:35', '192.168.2.65', 1),
(66, '2016-03-01 05:13:55', '::1', 1),
(67, '2016-03-01 07:21:24', '::1', 1),
(68, '2016-03-01 07:39:01', '::1', 1),
(69, '2016-03-01 08:04:48', '::1', 1),
(70, '2016-03-01 18:08:43', '::1', 1),
(71, '2016-03-02 16:36:24', '::1', 1),
(72, '2016-03-02 16:54:53', '::1', 1),
(73, '2016-03-02 18:30:56', '::1', 1),
(74, '2016-03-03 03:19:57', '::1', 1),
(75, '2016-03-03 14:23:46', '::1', 1),
(76, '2016-03-04 04:45:31', '::1', 1),
(77, '2016-03-04 17:30:19', '::1', 1),
(78, '2016-03-04 17:35:52', '::1', 1),
(79, '2016-03-04 20:19:00', '::1', 1),
(80, '2016-03-05 02:26:54', '::1', 1),
(81, '2016-03-05 17:46:16', '::1', 1),
(82, '2016-03-05 19:09:20', '1.39.60.155', 1),
(83, '2016-03-06 10:58:12', '1.39.63.182', 1),
(84, '2016-03-06 19:30:15', '1.39.60.147', 1),
(85, '2016-03-06 19:48:54', '1.39.60.147', 1),
(86, '2016-03-06 20:01:04', '175.136.214.244', 1),
(87, '2016-03-06 21:09:04', '1.39.63.170', 1),
(88, '2016-03-06 22:03:10', '1.39.60.77', 1),
(89, '2016-03-07 00:46:27', '1.39.60.77', 1),
(90, '2016-03-12 09:40:46', '1.39.80.35', 1),
(91, '2016-03-21 09:01:54', '113.193.147.168', 1),
(92, '2016-03-25 05:18:47', '60.52.64.71', 1),
(93, '2016-04-07 04:26:25', '14.140.167.94', 1),
(94, '2016-07-27 13:29:08', '122.174.67.249', 1),
(95, '2016-07-27 14:07:12', '108.247.232.35', 1),
(96, '2016-10-19 04:32:13', '182.65.99.183', 1),
(97, '2016-11-09 06:07:32', '::1', 1),
(98, '2017-03-13 11:09:31', '::1', 1),
(99, '2017-03-14 06:05:32', '::1', 1),
(100, '2017-03-14 08:29:23', '::1', 1),
(101, '2017-03-14 08:46:02', '::1', 1),
(102, '2017-03-23 11:02:13', '::1', 1),
(103, '2017-03-23 12:45:46', '::1', 1),
(104, '2017-03-23 13:16:20', '::1', 1),
(105, '2017-03-23 13:38:24', '::1', 1),
(106, '2017-03-24 06:32:55', '::1', 1),
(107, '2017-03-24 06:37:58', '::1', 1),
(108, '2017-03-24 06:42:24', '::1', 1),
(109, '2017-03-24 07:45:00', '::1', 1),
(110, '2017-03-24 10:05:03', '::1', 1),
(111, '2017-03-24 11:46:40', '::1', 1),
(112, '2017-03-25 06:15:31', '::1', 1);

-- --------------------------------------------------------

--
-- Table structure for table `sramcms_menus`
--

CREATE TABLE `sramcms_menus` (
  `id` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_type` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'uri',
  `page_id` int(11) NOT NULL DEFAULT '0',
  `url` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `menu_group_id` int(11) NOT NULL DEFAULT '0',
  `position` int(5) NOT NULL DEFAULT '0',
  `target` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `extra_attributes` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `menu_class` varchar(55) COLLATE utf8_unicode_ci NOT NULL,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `is_parent` tinyint(1) NOT NULL DEFAULT '0',
  `created_on` datetime NOT NULL,
  `created_by` bigint(20) NOT NULL,
  `updated_on` datetime NOT NULL,
  `updated_by` bigint(20) NOT NULL,
  `is_active` tinyint(4) NOT NULL,
  `is_delete` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `sramcms_menus`
--

INSERT INTO `sramcms_menus` (`id`, `name`, `link_type`, `page_id`, `url`, `menu_group_id`, `position`, `target`, `extra_attributes`, `menu_class`, `parent_id`, `is_parent`, `created_on`, `created_by`, `updated_on`, `updated_by`, `is_active`, `is_delete`) VALUES
(1, 'About us', 'page', 1, '', 1, 0, '', 'test', 'menu_class', 0, 0, '2017-03-24 10:30:16', 1, '2017-03-24 11:45:16', 1, 0, 1),
(2, 'Corrections and Clarifications', 'page', 3, '', 1, 0, '', 'test', 'menu_class', 0, 0, '2017-03-24 10:30:30', 1, '2017-03-24 11:41:55', 1, 0, 0),
(3, 'Terms of Use and Disclaimer', 'page', 6, '', 1, 0, '', 'test', 'menu_class', 0, 0, '2017-03-24 10:32:23', 1, '2017-03-24 11:18:43', 1, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `sramcms_menu_groups`
--

CREATE TABLE `sramcms_menu_groups` (
  `id` int(11) NOT NULL,
  `title` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `abbreviation` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_on` datetime NOT NULL,
  `updated_on` datetime NOT NULL,
  `created_by` bigint(20) NOT NULL,
  `updated_by` bigint(20) NOT NULL,
  `is_active` tinyint(4) NOT NULL,
  `is_delete` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Navigation groupings. Eg, header, sidebar, footer, etc';

--
-- Dumping data for table `sramcms_menu_groups`
--

INSERT INTO `sramcms_menu_groups` (`id`, `title`, `slug`, `abbreviation`, `created_on`, `updated_on`, `created_by`, `updated_by`, `is_active`, `is_delete`) VALUES
(1, 'Header Menu', 'header-menu', '', '2017-02-24 11:49:23', '2017-03-24 11:27:31', 1, 1, 1, 0),
(7, 'Footer Menu', 'footer-menu', '', '2017-03-24 10:34:40', '2017-03-24 10:38:46', 1, 1, 1, 0),
(8, 'Fooadasd asdasdasd', 'fooadasd-asdasdasd', '', '2017-03-24 11:26:28', '2017-03-24 11:26:53', 1, 1, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `sramcms_site_setting`
--

CREATE TABLE `sramcms_site_setting` (
  `setting_id` int(11) NOT NULL,
  `setting_key` varchar(55) NOT NULL,
  `setting_value` text NOT NULL,
  `setting_modify_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sramcms_site_setting`
--

INSERT INTO `sramcms_site_setting` (`setting_id`, `setting_key`, `setting_value`, `setting_modify_date`) VALUES
(1, 'mail_from_name', 'jeevanacharya.com', '2017-03-24 07:42:32'),
(2, 'from_email', 'admin@jeevanacharya.com', '2017-03-24 07:42:32'),
(3, 'to_email', 'admin@jeevanacharya.com', '2017-03-24 07:42:32'),
(4, 'mail_subject', 'Welcome jeevanacharya.com', '2017-03-24 07:42:32'),
(5, 'email_template', 'Welcome jeevanacharya.com', '2017-03-24 07:42:32'),
(6, 'login_points', 'sdasd', '2017-03-24 07:42:32'),
(7, 'new_user_points', 'asdasd', '2017-03-24 07:42:32'),
(8, 'referral_points', 'asdasd', '2017-03-24 07:42:32'),
(9, 'referred_user_register_points', 'asdasd', '2017-03-24 07:42:32'),
(10, 'submit', 'Submit', '2017-03-24 07:42:32'),
(11, 'action', 'settings', '2017-03-24 07:42:32');

-- --------------------------------------------------------

--
-- Table structure for table `sramcms_users`
--

CREATE TABLE `sramcms_users` (
  `user_id` bigint(20) NOT NULL,
  `user_name` varchar(155) DEFAULT NULL,
  `user_username` varchar(255) DEFAULT NULL,
  `user_password` varchar(255) DEFAULT NULL,
  `user_email_address` varchar(255) DEFAULT NULL,
  `user_referral_id` varchar(255) DEFAULT NULL,
  `user_company_name` varchar(255) DEFAULT NULL,
  `user_address_line1` varchar(255) DEFAULT NULL,
  `user_address_line2` varchar(255) DEFAULT NULL,
  `user_postal_code` varchar(255) DEFAULT NULL,
  `user_info` text,
  `user_date_format` varchar(20) DEFAULT NULL,
  `user_profile_image` varchar(100) DEFAULT NULL,
  `user_credit_points` int(11) NOT NULL,
  `user_referred_by` int(11) DEFAULT NULL,
  `user_folder_name` varchar(50) DEFAULT NULL,
  `user_brand_enable` tinyint(1) NOT NULL DEFAULT '0',
  `user_beacon_enable` tinyint(1) NOT NULL DEFAULT '0',
  `user_loyality_enable` tinyint(1) NOT NULL DEFAULT '0',
  `user_gift_enable` tinyint(1) NOT NULL DEFAULT '0',
  `user_whishlist_enable` tinyint(1) NOT NULL DEFAULT '0',
  `user_status` enum('A','I','D') NOT NULL DEFAULT 'I' COMMENT 'A-active, I- Inactive, D-Deleted',
  `user_created_on` datetime DEFAULT NULL,
  `user_created_ip` varchar(20) DEFAULT NULL,
  `user_updated_by` int(11) NOT NULL,
  `user_updated_on` datetime DEFAULT NULL,
  `user_updated_ip` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sramcms_users`
--

INSERT INTO `sramcms_users` (`user_id`, `user_name`, `user_username`, `user_password`, `user_email_address`, `user_referral_id`, `user_company_name`, `user_address_line1`, `user_address_line2`, `user_postal_code`, `user_info`, `user_date_format`, `user_profile_image`, `user_credit_points`, `user_referred_by`, `user_folder_name`, `user_brand_enable`, `user_beacon_enable`, `user_loyality_enable`, `user_gift_enable`, `user_whishlist_enable`, `user_status`, `user_created_on`, `user_created_ip`, `user_updated_by`, `user_updated_on`, `user_updated_ip`) VALUES
(32, 'mytest', 'mytest', '$2a$08$sACiqFX310nbuaLp6nfuFugrqOPRzM5VzWzVUoK1cr.T.y93ufuTu', 'mytest@gmail.com', '4F6C07F2', NULL, NULL, NULL, NULL, 'I am a Php developer', NULL, 'xCVglnYctXfkPHpJvNFK9AE16shwO5Gz87ToS4IuaZMWiLDd2r.jpg', 170, 0, 'f0Zkx1BMgqFRLG2O4uzTDltmHUEeWwa76cSVs5NyPhjn9KpIJA', 0, 0, 0, 0, 0, 'A', '2016-03-06 18:29:43', '1.39.60.147', 1, '2016-03-06 19:52:32', '1.39.60.147'),
(33, 'Subhash Raj', 'subhash', '$2a$08$TH0ZajfTLnjZBgCM5US/hujrqbItbPwrI01fkNWa/iHYfGXdgh.r.', 'tksubhashraj14@gmail.com', '5A5CA5DB', NULL, NULL, NULL, NULL, 'I am webdeveloper', NULL, 'WQ0H95ACu2qjyvgFRxL3KmesMtcDwaENdP1k8pIh6BlXOfGozZ.jpg', 80, 32, 'iSObeVLjgmT3ZGD9dqaPHMfCBkh5cyRznAJE0ItUvWQNw61rYo', 0, 0, 0, 0, 0, 'D', '2016-03-06 18:56:59', '1.39.60.147', 1, '2016-03-06 19:47:22', '1.39.60.147'),
(34, 'Test', 'tester', '$2a$08$DugIeYKxISG58iteGW4r/O1Eunj42jZrHhNHTK4TN3vh/VobrEZya', 'ain@justmobileinc.com', '8A424551', NULL, NULL, NULL, NULL, '', NULL, '', 100, 0, 'PmlSYpx9BMDq8jL5kbNaTzowG4i0KRVXhJOCF3dv7eAcr6UtsE', 0, 0, 0, 0, 0, 'A', '2016-03-06 20:02:37', '175.136.214.244', 1, '2016-11-09 06:13:39', '::1'),
(35, 'tester 2', 'tester2', '$2a$08$cHgVMvH2NcbYQTiZdftxqOWUbD7KoFf9tEk/Tfsix3FYBJyS1gZva', 'test@justmobileinc.com', '7FCF5F25', NULL, NULL, NULL, NULL, '', NULL, '', 50, 34, '4r5cQAa9qef6THyFv1mdNuRCpZxDOitYn8PsLjKhwoXIB7Vl20', 0, 0, 0, 0, 0, 'A', '2016-03-06 20:07:06', '175.136.214.244', 1, '2016-11-09 06:13:39', '::1'),
(36, 'vijayabharathi', 'bharathi', '$2a$08$DN0bYqz2kflnH/VUnO3QOutgthGVpGmlXPY2M9qWposBnf2M461Am', 'vijayabharathi91@gmail.com', '6DEFCE97', NULL, NULL, NULL, NULL, 'No one is going to hand me success. I must go out & get it myself.', NULL, 'iem904NfIKQs8tSB6p31WFYqJZGVbruLxOavzClw7jnoycHghR.jpg', 50, 0, 'vpu4TkHc02lnJM6ejqZULDXV3WmryOs1hoSG9xQPEFbRNBfA8I', 0, 0, 0, 0, 0, 'D', '2016-03-06 23:28:30', '122.174.182.118', 1, '2016-11-09 06:13:39', '::1'),
(37, 'Burhan', 'Khalib', '$2a$08$LKfkiW5Lb7yxG2/5VA0kqOUBfOqYrTkqDxXAq1aVkFuqMOESlH8pW', 'burhan@fanxt.com', '1F563298', NULL, NULL, NULL, NULL, 'great', NULL, 'J43rzDb8gPNivcwhI9TjA7fXy6toOR201EQlqVnapULZYsdWCM.png', 50, 0, 'thLGA0yFS91olVxs5KMOHY2fWm6vJqXaZTjpriezPEgBNdw7DC', 0, 0, 0, 0, 0, 'A', '2016-03-07 18:17:35', '175.136.214.244', 1, '2016-11-09 06:13:39', '::1'),
(38, 'subhash', 'subhashraj', '$2a$08$SHcm9nAIX6.V5ObHdYRiseAzPI.emCJ.x4S16LiGVp6gIHvmSWUPi', 'tksubhashraj124@gmail.com', 'EE067168', NULL, NULL, NULL, NULL, '', NULL, 'huEw69735pBVySLCZjdleosMFTnX1N2cQJfbYqOmvRG0iUgWK8.jpg', 140, 0, '0tgjhFdacrZTemfsHnQEAX9NvMGzYIbSB7kPRJ6i1LD2l5pWoV', 0, 0, 0, 0, 0, 'D', '2016-04-07 04:23:55', '14.140.167.94', 1, '2016-11-09 06:13:39', '::1');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `sramcms_blocks`
--
ALTER TABLE `sramcms_blocks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sramcms_cms_pages`
--
ALTER TABLE `sramcms_cms_pages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sramcms_log`
--
ALTER TABLE `sramcms_log`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sramcms_master_admin`
--
ALTER TABLE `sramcms_master_admin`
  ADD PRIMARY KEY (`admin_id`),
  ADD KEY `admin_username` (`admin_username`),
  ADD KEY `admin_password` (`admin_password`),
  ADD KEY `admin_ststus` (`admin_status`);

--
-- Indexes for table `sramcms_master_admin_login_history`
--
ALTER TABLE `sramcms_master_admin_login_history`
  ADD PRIMARY KEY (`login_id`);

--
-- Indexes for table `sramcms_menus`
--
ALTER TABLE `sramcms_menus`
  ADD PRIMARY KEY (`id`),
  ADD KEY `menu_group_id - normal` (`menu_group_id`);

--
-- Indexes for table `sramcms_menu_groups`
--
ALTER TABLE `sramcms_menu_groups`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sramcms_site_setting`
--
ALTER TABLE `sramcms_site_setting`
  ADD PRIMARY KEY (`setting_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `sramcms_blocks`
--
ALTER TABLE `sramcms_blocks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `sramcms_cms_pages`
--
ALTER TABLE `sramcms_cms_pages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `sramcms_log`
--
ALTER TABLE `sramcms_log`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT for table `sramcms_master_admin`
--
ALTER TABLE `sramcms_master_admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `sramcms_master_admin_login_history`
--
ALTER TABLE `sramcms_master_admin_login_history`
  MODIFY `login_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=113;
--
-- AUTO_INCREMENT for table `sramcms_menus`
--
ALTER TABLE `sramcms_menus`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `sramcms_menu_groups`
--
ALTER TABLE `sramcms_menu_groups`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `sramcms_site_setting`
--
ALTER TABLE `sramcms_site_setting`
  MODIFY `setting_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
